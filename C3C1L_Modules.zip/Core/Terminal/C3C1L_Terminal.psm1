# PowerShell Module: Terminal
function Terminal {
    Write-Output "Terminal module loaded."
}
