# PowerShell Module: Voice
function Voice {
    Write-Output "Voice module loaded."
}
