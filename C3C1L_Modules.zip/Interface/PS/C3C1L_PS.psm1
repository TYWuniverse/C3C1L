# PowerShell Module: PS
function PS {
    Write-Output "PS module loaded."
}
