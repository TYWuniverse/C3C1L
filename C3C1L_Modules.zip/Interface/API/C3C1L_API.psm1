# PowerShell Module: API
function API {
    Write-Output "API module loaded."
}
