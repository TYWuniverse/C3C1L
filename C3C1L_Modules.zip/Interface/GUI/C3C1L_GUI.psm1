# PowerShell Module: GUI
function GUI {
    Write-Output "GUI module loaded."
}
