# PowerShell Module: CMD
function CMD {
    Write-Output "CMD module loaded."
}
